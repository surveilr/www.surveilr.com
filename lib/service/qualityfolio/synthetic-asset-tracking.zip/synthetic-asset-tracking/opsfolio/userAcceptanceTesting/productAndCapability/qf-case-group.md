---
id: "GRP-0003"
SuiteId: SUT-0001
planId: ["PLN-0001"]
name: "Product & Capability — surveilr Platform Capabilities"
description: |
  "Group of test cases focused on validating the AI’s ability to clearly explain surveilr’s platform capabilities to technically oriented evaluators. Emphasis is on accuracy, completeness, trust-building, and guiding the user toward deeper technical resources or demos."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
tags: ["product capability", "technical", "architecture", "data privacy", "surveilr"]
---
### Project Overview
This group targets technical evaluators, security/privacy stakeholders, and compliance teams who need a clear, accurate understanding of surveilr’s platform architecture and operational model. Test cases in this group verify that the AI:

- Explains surveilr as a SQL-queryable private evidence warehouse
- Details single-binary deployment across Windows, Linux, and macOS
- Emphasizes local-first, edge-based approach for privacy
- Describes continuous surveillance and automated evidence collection
- Addresses machine-attestable evidence and audit readiness

### Scope
- Confirm that the AI articulates surveilr’s purpose, core features, and differentiators without ambiguity or omission.
- Ensure the AI conveys the single-binary, cross-platform nature and operational simplicity.
- Validate emphasis on local-first design, data residency control, and cryptographic protections.
- Verify explanation of continuous surveillance, automated collectors, and real-time ingestion pipelines.
- Assess whether the AI addresses tamper-evidence, provenance, and readiness for compliance audits.
- Confirm that the AI recommends downloading technical documentation and requesting a technical demo for deeper evaluation.