---
FII: "TC-SEO-001-N03"
groupId: "GRP-0005"
title: "CMMC Basics Search with Irrelevant External References"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Negative"]
priority: "Medium"
---
### Description
Verify the AI’s behavior when providing CMMC information but linking to unrelated or non-authoritative sources.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Observe whether external references are relevant.

### Expected Result
- Links to random, non-authoritative blogs or outdated documents.
- No Opsfolio resource link.
- Lacks a clear call to action.