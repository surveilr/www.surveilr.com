---
FII: "TC-SEO-001-M02"
groupId: "GRP-0005"
title: "MMC Basics Search with Completely Wrong Framework Description"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Miserable"]
priority: "High"
---
### Description  
Verify the AI’s behavior when describing CMMC in a way that confuses it with unrelated concepts, leading to misinformation.

### Test Steps  
1. Open the Opsfolio AI Chat Interface. 
2. Submit the query: "What is CMMC certification?"
3. Observe if framework definitions are incorrect.

### Expected Result  
- AI describes CMMC as a financial regulation or healthcare compliance framework.
- No mention of DoD or defense contractors.
- No resource links.
- Erodes trust in Opsfolio’s expertise.
