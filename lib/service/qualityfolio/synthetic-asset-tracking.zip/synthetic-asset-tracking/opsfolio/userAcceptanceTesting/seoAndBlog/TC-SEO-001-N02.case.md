---
FII: "TC-SEO-001-N02"
groupId: "GRP-0005"
title: "CMMC Basics Search with Minimal Context and No Resource Links"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Negative"]
priority: "Medium"
---
### Description
Verify the AI’s behavior when providing a vague or incomplete explanation of CMMC without linking resources or highlighting Opsfolio’s expertise.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Observe if jargon is used without explanation.

### Expected Result
- Uses overly technical compliance language.
- No analogies or plain-language breakdown.
- No links or CTA.
- User feels overwhelmed and disengages.