---
FII: "TC-SEO-002-M02"
groupId: "GRP-0005"
title: "POA&M Development Search with Irrelevant or Off-Topic Content"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Miserable"]
priority: "High"
---
### Description  
Verify the AI’s behavior when answering a POA&M query with unrelated compliance frameworks or non-security topics.

### Test Steps  
1. Launch the Opsfolio AI Chat Interface.  
2. Submit the query: "How do I create a Plan of Action and Milestones for CMMC?"
3. Observe relevance.

### Expected Result  
- Talks about unrelated frameworks (e.g., HIPAA, GDPR) without tying back to CMMC.
- Confuses the user and reduces credibility.