---
FII: "TC-SEO-001-P04"
groupId: "GRP-0005"
title: "CMMC Basics Search with Industry-Specific Context"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Positive"]
priority: "High"
---
### Description
Verify the AI’s ability to explain CMMC basics while tailoring the response to a specific industry or role.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Observe if the response addresses industry-specific concerns.

### Expected Result
- Explains CMMC basics in the context of defense contractors, subcontractors, and suppliers.
- Highlights relevance for small businesses and IT service providers.
- Links to Opsfolio’s industry-focused CMMC case studies.
- Ends with CTA: “See how companies like yours achieved compliance with Opsfolio.”
