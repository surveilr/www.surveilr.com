---
FII: "TC-SEO-001-P05"
groupId: "GRP-0005"
title: "CMMC Basics Search with Comparison to Other Frameworks"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Positive"]
priority: "High"
---
### Description
Verify the AI’s ability to explain CMMC basics by comparing it to other known compliance frameworks for better context.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Check if comparisons are used for clarity.

### Expected Result
- Explains CMMC basics alongside NIST 800-171, ISO 27001, or SOC 2.
- Highlights unique aspects of CMMC maturity levels and DoD requirements.
- Links to Opsfolio’s comparative compliance guide.
- Ends with CTA: “Read our full comparison of CMMC vs NIST 800-171.”