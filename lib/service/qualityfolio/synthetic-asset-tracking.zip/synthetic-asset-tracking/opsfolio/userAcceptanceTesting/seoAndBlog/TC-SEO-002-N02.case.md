---
FII: "TC-SEO-002-N02"
groupId: "GRP-0005"
title: "POA&M Development Search with Unclear Steps"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Negative"]
priority: "Medium"
---
### Description
Verify the AI’s behavior when describing POA&M creation but in an unstructured or confusing way.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "How do I create a Plan of Action and Milestones for CMMC?"
3. Observe the clarity and sequence of steps.

### Expected Result
- Information is scattered or out of logical order.
- No clear takeaway for the user.
- No links or CTA.