---
FII: "TC-SEO-002-M01"
groupId: "GRP-0005"
title: "POA&M Development Search with Incorrect CMMC Requirements"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Miserable"]
priority: "High"
---
### Description  
Verify the AI’s behavior when providing wrong or outdated POA&M requirements for CMMC.

### Test Steps  
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "How do I create a Plan of Action and Milestones for CMMC?"
3. Check for accuracy of compliance requirements.

### Expected Result  
- Uses outdated POA&M rules from pre-CMMC 2.0.
- Suggests non-compliant structures.
- No authoritative links.