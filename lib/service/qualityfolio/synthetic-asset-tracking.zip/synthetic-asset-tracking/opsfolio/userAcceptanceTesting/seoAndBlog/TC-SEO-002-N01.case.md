---
FII: "TC-SEO-002-N01"
groupId: "GRP-0005"
title: "CMMC Basics Search with Minimal Context and No Resource Links"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Negative"]
priority: "Medium"
---
### Description
Verify the AI’s behavior when giving only a generic definition of POA&M without explaining its role in CMMC.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "How do I create a Plan of Action and Milestones for CMMC?"
3. Observe for lack of CMMC context.

### Expected Result
- Defines POA&M generically.
- No mention of CMMC requirements or structure.
- No template link or CTA.