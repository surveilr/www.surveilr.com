---
FII: "TC-SEO-001-N01"
groupId: "GRP-0005"
title: "CMMC Basics Search with Minimal Context and No Resource Links"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Negative"]
priority: "Medium"
---
### Description
Verify the AI’s behavior when providing a vague or incomplete explanation of CMMC without linking resources or highlighting Opsfolio’s expertise.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Observe the AI response for missing details or lack of CTA.

### Expected Result
- Provides only a short, generic definition of CMMC.
- No mention of Opsfolio expertise.
- No links to authoritative or Opsfolio resources.
- Missed opportunity to invite further engagement.
