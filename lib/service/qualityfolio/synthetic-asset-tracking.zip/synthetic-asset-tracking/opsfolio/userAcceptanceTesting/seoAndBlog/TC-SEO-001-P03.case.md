---
FII: "TC-SEO-001-P03"
groupId: "GRP-0005"
title: "CMMC Basics Search with Compliance Roadmap and Next Steps"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Positive"]
priority: "High"
---
### Description
Verify the AI’s ability to explain CMMC basics and guide the user through a clear compliance roadmap.

### Test Steps
1. Open the Opsfolio AI Chat Interface.
2. Submit the query: "What is CMMC certification?"
3. Check for roadmap clarity and logical next steps.

### Expected Result
- Explains CMMC basics followed by “Steps to Get Certified.”
- Provides a logical flow from assessment → gap analysis → remediation → certification.
- Links to Opsfolio’s roadmap blog or PDF guide.
- Ends with CTA: “Start your compliance journey with our free checklist.”