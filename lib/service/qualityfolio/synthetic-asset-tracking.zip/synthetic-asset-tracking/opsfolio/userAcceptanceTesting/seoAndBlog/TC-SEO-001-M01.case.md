---
FII: "TC-SEO-001-M01"
groupId: "GRP-0005"
title: "CMMC Basics Search with Incorrect Information and No Engagement"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-08-08"
test_type: "Manual"
tags: ["Phase II","Miserable"]
priority: "High"
---
### Description  
Verify the AI’s behavior when delivering inaccurate, outdated, or irrelevant information about CMMC, leading to loss of trust.

### Test Steps  
1. Launch the Opsfolio AI Chat Interface.  
2. Submit the query: "What is CMMC certification?"
3. Observe the AI response for factual accuracy and tone.

### Expected Result  
- Gives outdated or incorrect description of CMMC.
- Confuses CMMC with unrelated frameworks.
- Overuses jargon without explanations.
- Provides no links or CTA.
- Creates a negative impression that damages trust.
