---
FII: TC-IBM-0010
groupId: GRP-0014
title: "Check whether all the Contextual Links in the 'The Complete Guide to Compliance-as-Code' page navigate properly to the corresponding url page."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Insight & Blog Page", "Entry Points - Cold outreach links"]
priority: "High"
test_cycles: ["1.0","1.1","1.2","1.5"]
scenario_type: "happy path"

---

### Description

- Verify that the Contextual Links in the 'The Complete Guide to Compliance-as-Code' page navigate properly to the corresponding url page.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Insights & Blog' menu in the home page.
3. Check the page loaded.
4. Click on the 'The Complete Guide to Compliance-as-Code' pop up link in the 'Insights & Blog' page.
5. Check the page loaded.
6. Check all the contextual links in the page navigates properly to the corresponding url page.
7. Close the browser.

### Expected Result

- All the contextual links shown in the page should navigate to the corresponding url pages.
