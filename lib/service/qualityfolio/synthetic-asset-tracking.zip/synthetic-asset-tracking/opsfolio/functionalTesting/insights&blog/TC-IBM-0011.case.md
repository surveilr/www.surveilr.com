---
FII: TC-IBM-0011
groupId: GRP-0014
title: "Check whether the 'CMMC Scoping in the Cloud Era: Three Level 1 Scenarios' pop up link navigates properly to the corresponding page url (https://opsfolio.com/blog/cmmc-evidence-guide/)."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Insight & Blog Page", "Conversion Path- CTA buttons"]
priority: "High"
test_cycles: ["1.0","1.1","1.2","1.5"]
scenario_type: "happy path"

---

### Description

- Verify that the 'CMMC Scoping in the Cloud Era: Three Level 1 Scenarios' pop up link navigates properly to the corresponding page url (https://opsfolio.com/blog/cmmc-evidence-guide/).

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Insights & Blog' menu in the home page.
3. Check the page loaded.
4. Click on the 'CMMC Scoping in the Cloud Era: Three Level 1 Scenarios' pop up on the page.
5. Check whether the page navigated to the corresponding page (https://opsfolio.com/blog/cmmc-evidence-guide/).
6. Close the browser.

### Expected Result

- The page should navigates to the correct url page.
