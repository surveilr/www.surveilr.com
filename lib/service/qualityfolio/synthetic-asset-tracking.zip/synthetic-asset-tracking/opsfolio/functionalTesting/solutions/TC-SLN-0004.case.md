---
FII: "TC-SLN-0004"
groupId: "GRP-0015"
title: "Check - Breadcrumb Navigation Visibility and Clickable Home Link on CISOs & Security Engineers"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["Breadcrumb"]
priority: "Low"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that the breadcrumb `Home / Role / CISOs & Security Engineers` is displayed correctly on the CISOs & Security Engineers and that only the **Home** link is clickable.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. Scroll to the footer section and click the ‘CISOs & Security Engineers’ link under the ‘Solutions’ heading.  
3. Verify that the breadcrumb `Home / Role /CISOs & Security Engineers` is displayed at the top of the page.  
4. Confirm that **Home** is rendered as a clickable link.  
5. Confirm that **Role** and **CISOs & Security Engineers** are displayed as plain text (not links).  
6. Click the **Home** link and verify that it redirects to the Opsfolio homepage.  
7. Close the browser.

### Expected Result

- The breadcrumb should be displayed as `Home / Role / CISOs & Security Engineers`.  
- Only the **Home** breadcrumb should be clickable and should redirect correctly.  
- **Role** and **CISOs & Security Engineers** should be displayed as non-clickable plain text.  
