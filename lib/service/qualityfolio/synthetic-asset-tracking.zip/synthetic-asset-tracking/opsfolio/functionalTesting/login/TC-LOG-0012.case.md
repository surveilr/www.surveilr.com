---
FII: "TC-LOG-0012"
groupId: "GRP-0008"
title: "Navigation to Sign Up page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page",]
priority: "Medium"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that the “Sign Up” link navigates the user to the registration page.

### Pre-Conditions

- The user is on the Opsfolio login page.  
- A “Sign Up” link is available.

### Test Steps

1. Navigate to the login page.  
2. Locate the “Sign Up” link.  
3. Click on the “Sign Up” link.  

### Expected Result

- The user is redirected to the registration page.  
- The page displays fields for creating a new account (e.g., username, email, password, confirm password).  
- The user is not logged in yet.