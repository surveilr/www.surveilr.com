---
FII: "TC-LOG-0010"
groupId: "GRP-0008"
title: "Login with expired credentials"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page","Account Management"]
priority: "Medium"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that a user with expired credentials cannot login.

### Pre-Conditions

- The user account exists but the credentials are expired.

### Test Steps

1. Navigate to the login page.  
2. Enter the expired username/email.  
3. Enter the corresponding password.  
4. Click on the “Login” button.  

### Expected Result

- Login should fail.  
- An error message such as “Your password has expired, please reset it” should be displayed.  
- The user should be redirected to the password reset flow if available.