---
FII: "TC-LOG-0013"
groupId: "GRP-0008"
title: "Forgot Password link broken or inaccessible"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page"]
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify system behavior if the “Forgot Password” link is broken or does not navigate correctly.

### Pre-Conditions

- The user is on the login page.  
- A “Forgot Password” link is displayed.

### Test Steps

1. Navigate to the login page.  
2. Click on the “Forgot Password” link.  

### Expected Result

- If the link is broken, the system should display an error page or a clear message (e.g., “Page not found” or “Service temporarily unavailable”).  
- The application should not crash or expose server errors.  
- The user should remain safe on the platform without security risks.