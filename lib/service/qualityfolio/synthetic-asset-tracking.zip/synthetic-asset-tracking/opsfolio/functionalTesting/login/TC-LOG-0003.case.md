---
FII: "TC-LOG-0003"  
groupId: "GRP-0008"  
title: "Password visibility toggle"  
created_by: "arun-ramanan@netspective.in"  
created_at: "2025-09-19"  
test_type: "Manual"  
tags: ["Login Page","Usability"]  
priority: "Low"  
test_cycles: ["1.4", "1.5"]
scenario_type: "happy path" 

---

### Description

- Verify that toggling password visibility (show/hide) works correctly.

### Pre-Conditions

- The user is on the login page.  
- There is a password field with a visibility toggle (eye icon or similar).

### Test Steps

1. Navigate to the login page.  
2. Enter a password into the password field (masked by default).  
3. Click the visibility toggle to unmask the password.  
4. Verify the characters are visible.  
5. Click again to mask the password.

### Expected Result

- Toggling once shows the password in plain text.  
- Toggling again hides the password.  
- All entered characters remain intact.