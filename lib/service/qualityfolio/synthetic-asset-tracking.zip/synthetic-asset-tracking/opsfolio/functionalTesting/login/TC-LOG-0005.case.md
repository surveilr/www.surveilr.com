---
FII: "TC-LOG-0005"  
groupId: "GRP-0008"  
title: "Login journey parameter preserved after login"  
created_by: "arun-ramanan@netspective.in"  
created_at: "2025-09-19"  
test_type: "Manual"  
tags: ["Login Page","Journey Parameter"]  
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "happy path"  

---

### Description

- Verify that the “journey=cmmc-self-assessment” parameter is respected after login.

### Pre-Conditions

- The user has valid credentials.  
- The login URL contains the `journey=cmmc-self-assessment` parameter.

### Test Steps

1. Open the browser and navigate to `https://opsfolio.com/login?journey=cmmc-self-assessment`.  
2. Enter valid email and password.  
3. Click “Login”.  

### Expected Result

- The user is redirected to the CMMC self-assessment dashboard.  
- The journey parameter is preserved, confirming correct workflow routing.