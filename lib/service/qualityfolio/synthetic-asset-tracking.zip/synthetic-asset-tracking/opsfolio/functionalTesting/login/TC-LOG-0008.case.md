---
FII: "TC-LOG-0008"
groupId: "GRP-0008"
title: "Login with empty fields"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page","Validation"]
priority: "Medium"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that login is not possible when both emailid and password fields are left empty.

### Pre-Conditions

- User is on the login page.

### Test Steps

1. Navigate to the login page.  
2. Leave both the emailid and password fields blank.  
3. Click on the “Login” button.  

### Expected Result

- Login should fail.  
- A validation message should be displayed (e.g., “Username and password are required”).  
- The user should remain on the login page.
