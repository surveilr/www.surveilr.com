---
FII: "TC-LOG-0007"
groupId: "GRP-0008"
title: "Login with invalid emailid"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page"]
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that login fails when an invalid emailid is entered with a valid password.

### Pre-Conditions

- The user has an invalid emailid and a valid password.

### Test Steps

1. Navigate to the login page.  
2. Enter an invalid email.  
3. Enter a valid password.  
4. Click on the “Login” button.  

### Expected Result

- Login should fail.  
- An error message should be displayed.  
- The user should remain on the login page.
