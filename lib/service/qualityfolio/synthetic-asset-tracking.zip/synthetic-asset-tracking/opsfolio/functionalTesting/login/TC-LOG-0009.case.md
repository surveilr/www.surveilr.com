---
FII: "TC-LOG-0009"
groupId: "GRP-0008"
title: "Login with SQL injection attempt"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page","Security"]
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that the login form is protected against SQL injection attempts.

### Pre-Conditions

- User is on the login page.

### Test Steps

1. Navigate to the login page.  
2. Enter `admin' OR '1'='1` in the username/email field.  
3. Enter any random text in the password field.  
4. Click on the “Login” button.  

### Expected Result

- Login should fail.  
- The system should not crash or expose database errors.  
- A standard error message should be displayed (e.g., “Invalid username or password”).