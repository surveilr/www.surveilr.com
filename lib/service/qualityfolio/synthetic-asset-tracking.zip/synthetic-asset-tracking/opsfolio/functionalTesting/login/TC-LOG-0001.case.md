---
FII: "TC-LOG-0001"
groupId: "GRP-0008"
title: "Application login check"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page"]
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "happy path"
bugId: ["OP-001"]
---
### Description

Ensure the application login and logout.

### Pre-Conditions

- The user has valid login credentials (emailid and password).

### Test Steps:

1. Navigate to the URL and ensure the page loads successfully.
2. Perform login with valid credentials.
3. Perform logout.
4. Close the browser.

### Expected Result:

- The application should login and logout properly.
