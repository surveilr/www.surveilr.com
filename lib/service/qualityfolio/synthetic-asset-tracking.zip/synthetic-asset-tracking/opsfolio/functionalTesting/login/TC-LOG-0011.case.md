---
FII: "TC-LOG-0011"
groupId: "GRP-0008"
title: "Login with locked account"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-19"
test_type: "Manual"
tags: ["Login Page"]
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "unhappy path"
---

### Description

- Verify that a locked user account cannot login.

### Pre-Conditions

- The user account is locked (e.g., due to multiple failed attempts).

### Test Steps

1. Navigate to the login page.  
2. Enter valid username/email of the locked account.  
3. Enter the valid password.  
4. Click on the “Login” button.  

### Expected Result

- Login should fail.  
- An error message such as “Your account is locked. Contact administrator” should be displayed.  
- The user should remain on the login page.