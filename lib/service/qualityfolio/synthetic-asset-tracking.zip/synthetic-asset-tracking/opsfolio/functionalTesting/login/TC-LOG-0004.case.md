---
FII: "TC-LOG-0004"  
groupId: "GRP-0008"  
title: "Navigation to Forgot Password page"  
created_by: "arun-ramanan@netspective.in"  
created_at: "2025-09-19"  
test_type: "Manual"  
tags: ["Login Page",]  
priority: "Medium"  
test_cycles: ["1.4", "1.5"]
scenario_type: "happy path"  
---

### Description

- Verify that the “Forgot Password” link navigates correctly.

### Pre-Conditions

- The user is on the login page.  
- A “Forgot Password” link is available.

### Test Steps

1. Navigate to the login page.  
2. Click on the “Forgot Password” link.  

### Expected Result

- The user is redirected to the password reset page.  
- The page contains fields to start the password recovery process.  
- No login credentials are required to view the reset page.
