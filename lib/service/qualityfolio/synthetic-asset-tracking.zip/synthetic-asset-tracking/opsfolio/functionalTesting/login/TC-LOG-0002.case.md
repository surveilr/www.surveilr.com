---
FII: "TC-LOG-0002"  
groupId: "GRP-0008"  
title: "Login with valid credentials"  
created_by: "arun-ramanan@netspective.in"  
created_at: "2025-09-19"  
test_type: "Manual"  
tags: ["Login Page"]  
priority: "High"
test_cycles: ["1.4", "1.5"]
scenario_type: "happy path"  

---

### Description

- Verify that a user can login using valid emailid and password.

### Pre-Conditions

- The user has valid login credentials: emailid and password.  
- The user is on the Opsfolio login page for CMMC self-assessment: `https://opsfolio.com/login?journey=cmmc-self-assessment`.

### Test Steps

1. Navigate to the login page URL.  
2. Ensure the login page loads with fields for email and password, and a submit button.  
3. Enter valid email.  
4. Enter valid password.  
5. Click on the “Login” button.  

### Expected Result

- The user is successfully authenticated and redirected to the dashboard or landing page for CMMC self-assessment.  
- No error messages are displayed.  
- The user's name or identifier is displayed in the UI.
