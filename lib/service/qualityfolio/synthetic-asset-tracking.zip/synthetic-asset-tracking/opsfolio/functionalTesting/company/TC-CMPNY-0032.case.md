---
FII: TC-CMPNY-0032
groupId: GRP-0017
title: "Check whether the user can submit the 'Contact' form without filling the mandatory fields."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Company", "Analytics - Self Assessment"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
scenario_type: "unhappy path"
---

### Description

- Validate that the user can submit the 'Contact' form without fill the mandatory fields.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Contact' menu in the footer section.
3. Check the page navigated.
4. Fill the form by leaving a mandatory field as empty.
5. Check whether there is a validation message displayed while submission of the form. 
6. Close the browser.

### Expected Result

- There should be an validation message displayed while the time of form submission