---
FII: TC-CMPNY-0018
groupId: GRP-0017
title: "Check whether the 'Schedule Demo' button option in the 'Compliance as Code' page navigates properly"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Company", "Conversion Paths - CTA buttons"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

- Validate that when click on the 'Schedule Demo' button in the 'Compliance as Code' page navigate to the respective page.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Navigate to the footer section.
3. Click on the 'Compliance as Code' menu under the 'Company' tab.
4. Check the page navigated.
5. Click on the 'Schedule Demo' button in the 'Compliance as Code' page.
6. Check whether the page navigates properly.
7. Close the browser.

### Expected Result

- The 'Schedule Demo' button in the 'Compliance as Code' page navigates properly.