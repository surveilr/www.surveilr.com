---
id: GRP-0017
SuiteId: SUT-0002
planId: ["PLN-0002"]
name: "Company Section (Footer) Test Cases"
description: "Test cases validating the navigation, visibility, responsiveness, accessibility, and functionality of the 'Company' section in the website footer. It ensures that all links (About, Resources, Blog, Compliance as Code, Evidence Warehouse, Contact) are displayed correctly, route to the appropriate pages, and deliver a seamless user experience across devices."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
tags: ["UI validation", "footer navigation", "company links", "responsiveness", "accessibility", "link validation"]

---

## Overview

The **Company Section (Footer)** provides users with access to key informational and support pages, including About, Resources, Blog, Compliance as Code, Evidence Warehouse, and Contact. This test group validates that all links in the Company column of the footer are visible, functional, and accessible across devices.

## Key Functional Areas

### 🔹 Link Visibility and Functionality

* **About**

  * Ensure link is visible in the footer across all viewports.
  * Validate correct routing to the About page.

* **Resources**

  * Confirm Resources link renders correctly and routes to the resource hub.
  * Validate availability of downloadable/interactive materials.

* **Blog**

  * Ensure Blog link is accessible and opens the blog section.
  * Validate latest posts are displayed as expected.

* **Compliance as Code**

  * Confirm footer link routes to the Compliance as Code section.
  * Validate that automation-related information loads correctly.

* **Evidence Warehouse**

  * Verify Evidence Warehouse link routes to the appropriate section.
  * Confirm page loads relevant CTAs (centralization, upload, or access).

* **Contact**

  * Ensure Contact link is visible and routes to the contact page/form.
  * Validate form submission (if present) and confirm required fields.

### 🔹 Accessibility and Responsiveness

* Verify all links are keyboard navigable (tab/focus states).
* Confirm screen reader compatibility with descriptive link names.
* Validate rendering on desktop, tablet, and mobile.

### 🔹 Performance

* Ensure all linked pages load within acceptable response times.
* Verify no broken links or redirect errors.

---


