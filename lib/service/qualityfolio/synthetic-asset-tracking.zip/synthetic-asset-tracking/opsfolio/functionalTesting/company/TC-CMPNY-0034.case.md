---
FII: TC-CMPNY-0034
groupId: GRP-0017
title: "Check whether the content for the mail received is correct for contact form submission"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Company", "Analytics - Self Assessment"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

- Validate that the content for the mail received is correct for the contact submission.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Contact' menu in the footer section.
3. Check the page navigated.
4. Fill the fields and submit the form.
5. Check the inbox of the mail id provided in the form. 
6. Check whether there is mail received to the inbox regarding the details.
7. Check whether the content of the mail received is correct.
8. Close the browser.

### Expected Result

- The content of the mail received should be correct.