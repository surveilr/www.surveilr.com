---
FII: TC-CMPNY-0041
groupId: GRP-0017
title: "Check whether the content for the mail received is correct"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Company", "Analytics - Self Assessment"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

- Validate that the content for the mail received is correct.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Contact' menu in the footer section.
3. Click on the 'Get Started' button in the contact page.
4. Check the page navigated.
5. Fill the fields and submit the form.
6. Check the inbox of the mail id provided in the form. 
7. Check whether there is mail received to the inbox regarding the details.
8. Check whether the content of the mail received is correct.
9. Close the browser.

### Expected Result

- The content of the mail received should be correct.