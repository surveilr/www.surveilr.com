---
FII: TC-CMPNY-0006
groupId: GRP-0017
title:  Check whether the 'Contact' menu under the 'Company' tab navigates properly
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Company"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

Verify that the user clicks on the 'Contact' menu the page should navigate properly

### Test Steps:

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Navigate to the footer section.
3. Click on the 'Contact' menu option under 'Company' tab.
4. check whether the navigation is proper
5. Close the browser.

### Expected Result:

- The 'Contact' tab should navigate properly to the correct page.
