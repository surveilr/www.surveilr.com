---
FII: TC-CMPNY-0014
groupId: GRP-0017
title:  Check whether the 'Get Started' button navigates properly
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["Home Page", "Conversion Paths - CTA buttons"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

Verify that the 'Get Started' button in the home page navigates properly.

### Test Steps:

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Click on the 'Contact' menu in the footer section.
3. Click on the 'Get Started' from the contact page.
4. check whether the navigation is proper
5. Close the browser.

### Expected Result:

- The "Get Started" button should navigate properly.
