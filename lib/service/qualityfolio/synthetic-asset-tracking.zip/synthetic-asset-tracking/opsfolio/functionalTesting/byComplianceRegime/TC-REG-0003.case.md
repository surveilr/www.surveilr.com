---
FII: "TC-REG-0003"
groupId: "GRP-0011"
title: "Check - By Compliance Regime Dropdown Option Selection and Closing Behavior"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Automation"
tags: ["By Compliance Regime Dropdown", "Interaction"]
priority: "Low"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each dropdown option can be selected and that the dropdown closes after selection.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Compliance Regime' dropdown.  
3. Select each compliance regime option one by one using mouse click.  
4. Verify that the dropdown closes automatically after selection.  
5. Repeat step 3 using keyboard navigation (arrow keys + Enter).  
6. Close the browser.

### Expected Result

- Each option should be selectable via both mouse and keyboard.  
- The dropdown should close automatically after each selection.  
