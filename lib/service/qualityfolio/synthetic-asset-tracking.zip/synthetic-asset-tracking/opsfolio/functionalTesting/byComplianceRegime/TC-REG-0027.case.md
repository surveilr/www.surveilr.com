---
FII: "TC-REG-0027"
groupId: "GRP-0011"
title: "Check - By Compliance Regime HIPAA Navigation and Control Explorer Breadcrumb"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Breadcrumb Navigation", "UI validation"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting **HIPAA** from the 'By Compliance Regime' dropdown navigates correctly to the HIPAA page and that the breadcrumb displays correctly.  
- Only the **Home** link in the breadcrumb should be clickable.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → HIPAA**.  
3. Click the **Control Explorer** link for HIPAA.  
4. Observe the breadcrumb: Home / Regime / HIPAA / Controls.  
5. Verify that only the **Home** link is clickable, while Regime, HIPAA, and Controls are not clickable.  
6. Close the browser.

### Expected Result

- Selecting HIPAA should navigate to the HIPAA page successfully.  
- The Control Explorer page should display with the correct breadcrumb: Home / Regime / HIPAA / Controls.  
- Only the **Home** link should be clickable; other breadcrumb items should not be clickable.  
