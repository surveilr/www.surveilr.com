---
FII: "TC-REG-0018"
groupId: "GRP-0011"
title: "Check - Link Redirection on GDPR Compliance Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each link on the GDPR compliance page redirects to the correct target page or action.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → GDPR**.  
3. Click on each link and verify redirection:  
   - **Start GDPR Assessment** → Redirects to GDPR assessment page or form.  
   - **Book Consultation** → Opens consultation booking form/scheduler.  
   - **Get Started Today** → Redirects to GDPR onboarding/signup flow.  
   - **View Resources** → Opens GDPR-related resources page or knowledge base.  
4. Close the browser.

### Expected Result

- Each link should redirect correctly to its respective target page or action without errors.  
