---
FII: "TC-REG-0025"
groupId: "GRP-0011"
title: "Check - By Compliance Regime SOC2 Navigation and Control Explorer Breadcrumb"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Breadcrumb Navigation", "UI validation"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting **SOC2** from the 'By Compliance Regime' dropdown navigates correctly to the SOC2 page and that the breadcrumb displays correctly.  
- Only the **Home** link in the breadcrumb should be clickable.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → SOC2**.  
3. Click the **Control Explorer** link for SOC2.  
4. Observe the breadcrumb: Home / Regime / SOC2 / Controls.  
5. Verify that only the **Home** link is clickable, while Regime, SOC2, and Controls are not clickable.  
6. Close the browser.

### Expected Result

- Selecting SOC2 should navigate to the SOC2 page successfully.  
- The Control Explorer page should display with the correct breadcrumb: Home / Regime / SOC2 / Controls.  
- Only the **Home** link should be clickable; other breadcrumb items should not be clickable.  
