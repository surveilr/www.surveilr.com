---
FII: "TC-REG-0001"
groupId: "GRP-0011"
title: "Check - By Compliance Regime Dropdown Visibility and Label Rendering"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Automation"
tags: ["By Compliance Regime Dropdown"]
priority: "Low"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that the 'By Compliance Regime' dropdown is visible in the navigation bar and its label is displayed correctly.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. Verify that the 'By Compliance Regime' dropdown is visible in the navigation bar.  
3. Check that the dropdown label is displayed correctly.  
4. Close the browser.

### Expected Result

- The 'By Compliance Regime' dropdown should be visible on the homepage navigation bar.  
- The dropdown label should match the expected design text.  
