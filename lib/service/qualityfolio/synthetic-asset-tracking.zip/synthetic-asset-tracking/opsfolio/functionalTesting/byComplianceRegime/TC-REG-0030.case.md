---
FII: "TC-REG-0030"
groupId: "GRP-0011"
title: "Check - ISO 27001 Controls Navigation and Action Links Validation"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "ISO 27001", "UI validation", ]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting **ISO 27001** from the 'By Compliance Regime' dropdown navigates correctly to the Control Explorer page, which displays ISO 27001 controls along with the **Download Checklist** and **Talk to Our Experts** links.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, expand the 'By Compliance Regime' dropdown.  
3. Select **ISO 27001** from the dropdown options.  
4. On the ISO 27001 page, click the **Control Explorer** link.  
5. Verify that the page displays ISO 27001 controls listed under them.  
6. Confirm that the page contains a **Download Checklist** link.  
7. Confirm that the page contains a **Talk to Our Experts** link.  
8. Close the browser.  

### Expected Result

- Selecting **ISO 27001** should redirect to the Control Explorer page.  
- The page should display ISO 27001 controls clearly.  
- The **Download Checklist** link should be visible and functional.  
- The **Talk to Our Experts** link should be visible and functional.  
