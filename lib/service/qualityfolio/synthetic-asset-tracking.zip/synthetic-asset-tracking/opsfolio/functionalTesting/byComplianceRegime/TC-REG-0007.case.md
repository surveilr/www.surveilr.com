---
FII: "TC-REG-0007"
groupId: "GRP-0011"
title: "Check - Breadcrumb Navigation Visibility and Clickable Home Link on HIPAA Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Automation"
tags: [ "By Compliance Regime"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that the breadcrumb `Home / Regime / HIPAA` is displayed correctly on the HIPAA page and that only the **Home** link is clickable.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → HIPAA**.  
3. Verify that the breadcrumb `Home / Regime / HIPAA` is displayed at the top of the page.  
4. Confirm that **Home** is rendered as a clickable link.  
5. Confirm that **Regime** and **HIPAA** are displayed as plain text (not links).  
6. Click the **Home** link and verify that it redirects to the Opsfolio homepage.  
7. Close the browser.

### Expected Result

- The breadcrumb should be displayed as `Home / Regime / HIPAA`.  
- Only the **Home** breadcrumb should be clickable and should redirect correctly.  
- **Regime** and **HIPAA** should be displayed as non-clickable plain text.  
