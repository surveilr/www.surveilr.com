---
FII: "TC-REG-0002"
groupId: "GRP-0011"
title: "Check - By Compliance Regime Dropdown Options Availability"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Automation"
tags: ["By Compliance Regime Dropdown",]
priority: "Medium"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that all expected compliance regimes are available in the 'By Compliance Regime' dropdown.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Compliance Regime' dropdown.  
3. Verify that the following options are listed:  
   - SOC2  
   - HIPAA  
   - ISO 27001  
   - CMMC  
   - FedRAMP  
   - HITRUST  
   - GDPR  
   - PCI DSS  
   - CCPA  
   - European CRA  
4. Close the browser.

### Expected Result

- All ten compliance regime options should be present in the dropdown.  
