---
FII: "TC-REG-0026"
groupId: "GRP-0011"
title: "Check - By Compliance Regime SOC2 Control Explorer Functionality"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "SOC2", "Control Explorer","Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting SOC2 from the 'By Compliance Regime' dropdown loads the Control Explorer page correctly.  
- Verify that SOC2 Type 1 and SOC2 Type 2 tabs display their respective controls, and check that links for downloading the SOC2 checklist and contacting experts are functional.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, expand **By Compliance Regime** and select **SOC2**.  
3. On the SOC2 Control Explorer page, verify that **SOC2 Type 1** and **SOC2 Type 2** tabs are visible.  
4. Click the **SOC2 Type 1** tab and confirm that all corresponding controls are listed correctly.  
5. Click the **SOC2 Type 2** tab and confirm that all corresponding controls are listed correctly.  
6. Verify that the **Download SOC2 Checklist** link is visible and clickable.  
7. Verify that the **Talk to Our Experts** link is visible and navigates to the correct contact/support page.  
8. Close the browser.

### Expected Result

- The SOC2 Control Explorer page loads successfully after selecting SOC2.  
- SOC2 Type 1 and SOC2 Type 2 tabs are displayed and show the correct list of controls when clicked.  
- The **Download SOC2 Checklist** link is clickable and functions correctly.  
- The **Talk to Our Experts** link is visible and navigates to the intended contact/support page.  
