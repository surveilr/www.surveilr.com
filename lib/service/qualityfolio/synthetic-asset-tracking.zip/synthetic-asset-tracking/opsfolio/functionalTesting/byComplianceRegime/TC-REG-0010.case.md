---
FII: "TC-REG-0010"
groupId: "GRP-0011"
title: "Check - Link Redirection on ISO 27001 Compliance Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Automation"
tags: ["By Compliance Regime Dropdown", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each link on the ISO 27001 compliance page redirects or responds correctly to its intended target action.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → ISO 27001**.  
3. Click on each link and verify redirection or action:  
   - **Start ISO Assessment** → Redirects to ISO assessment initiation page/form.  
   - **Talk to ISO Expert** → Opens consultation form or scheduling page with an ISO expert.  
   - **Control Explorer** → Redirects to ISO 27001 control explorer module/page.  
   - **Download ISO Guide** → Initiates download or opens the ISO guide resource.  
4. Close the browser.

### Expected Result

- Each link should redirect or perform the expected action without errors, ensuring proper navigation and functionality.
