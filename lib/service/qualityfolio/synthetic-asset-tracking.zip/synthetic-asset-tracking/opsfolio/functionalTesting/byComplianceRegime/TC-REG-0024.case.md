---
FII: "TC-REG-0024"
groupId: "GRP-0011"
title: "Check - European CRA Page Links Visibility and Navigation"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["European CRA", "Links Validation", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that all key links on the European CRA page are visible, correctly labeled, and navigate to the expected destinations.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → European CRA**.  
3. Verify that the following links are present on the page:  
   - Get CRA Readiness Assessment  
   - Talk to CRA Expert  
   - SOC2-Audit Attestation  
   - Surveilr  
   - Qualityfolio  
   - Fleetfolio  
   - NUP  
   - Start CRA Readiness Pilot  
   - Contact CRA Expert  
4. Click each link and confirm it navigates to the correct destination (page or modal).  
5. Verify that the links are styled correctly (visible, accessible, and consistent with UI design).  
6. Close the browser.

### Expected Result

- All listed links should be visible and correctly labeled on the European CRA page.  
- Each link should navigate to the expected destination.  
- Links should be accessible and follow design consistency.  
