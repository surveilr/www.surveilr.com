---
FII: "TC-REG-0012"
groupId: "GRP-0011"
title: "Check - Link Redirection on CMMC Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each link on the **CMMC** page redirects to the correct target page or action.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → CMMC**.  
3. Click on each link and verify redirection:  
   - **Start CMMC Self Assessment** → Redirects to self-assessment initiation page/form.  
   - **Talk to CMMC Expert** → Opens consultation/contact form with CMMC expert.  
   - **Control Explorer** → Redirects to CMMC control explorer interface.  
   - **Start CMMC Assessment** → Redirects to assessment workflow initiation page.  
   - **Download CMMC Guide** → Initiates download or opens the CMMC guide resource.  
4. Close the browser.

### Expected Result

- Each link should redirect correctly to its respective target page or resource without errors.
