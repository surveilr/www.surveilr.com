---
FII: "TC-REG-0014"
groupId: "GRP-0011"
title: "Check - Link Redirection on FedRAMP Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each link on the FedRAMP page redirects to the correct target page or resource.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → FedRAMP**.  
3. Click on each link and verify redirection:  
   - **Start FedRAMP Assessment (1st occurrence)** → Redirects to assessment initiation page/form.  
   - **Talk to FedRAMP Expert** → Opens consultation/contact form page.  
   - **Start FedRAMP Assessment (2nd occurrence)** → Redirects to the same assessment initiation page/form as the first.  
   - **Download FedRAMP Guide** → Initiates download or opens the guide resource.  
4. Close the browser.

### Expected Result

- Each link should redirect correctly to its respective target page without errors.  
- Duplicate **Start FedRAMP Assessment** links should behave consistently and redirect to the same target.
