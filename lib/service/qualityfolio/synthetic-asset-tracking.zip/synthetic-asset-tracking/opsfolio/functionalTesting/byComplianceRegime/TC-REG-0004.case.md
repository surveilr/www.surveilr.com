---
FII: "TC-REG-0004"
groupId: "GRP-0011"
title: "Check - By Compliance Regime Dropdown Content Filtering and Compliance-Specific Messaging"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Automation"
tags: ["By Compliance Regime Dropdown","Conversion paths - Sales/offer page"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"

---

### Description

- Validate that selecting a compliance regime filters or routes content correctly and displays tailored compliance-specific messaging, resources, or CTAs.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Compliance Regime' dropdown.  
3. Select "SOC2" and verify that SOC2-specific content loads.  
4. Repeat for HIPAA, ISO 27001, CMMC, FedRAMP, HITRUST, GDPR, PCI DSS, CCPA, and European CRA.  
5. Confirm that compliance-specific resources, dashboards, or CTAs appear for each regime.  
6. Close the browser.

### Expected Result

- Selecting a compliance regime should filter or route content accordingly.  
- Tailored compliance-specific resources, dashboards, or CTAs should appear for each regime.  
