---
FII: "TC-REG-0006"
groupId: "GRP-0011"
title: "Check - Link Redirection on SOC2 Compliance Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Automation"
tags: ["By Compliance Regime", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that each link on the SOC2 compliance page redirects to the correct target page.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → SOC2**.  
3. Click on each link and verify redirection:  
   - **Get SOC2 Readiness Assessment** → Redirects to SOC2 readiness assessment form/page.  
   - **Download SOC2 Guide** → Initiates download or opens SOC2 guide resource.  
   - **Control Explorer** → Opens SOC2 control explorer page.  
   - **SOC2 Type 1 - Get Started** → Redirects to SOC2 Type 1 onboarding/get started page.  
   - **SOC2 Type 2 - Get Started** → Redirects to SOC2 Type 2 onboarding/get started page.  
   - **SOC2+ (Custom) - Get Started** → Redirects to SOC2+ custom onboarding/get started page.  
   - **Start Free Assessment** → Redirects to free assessment form/page.  
   - **Talk to SOC2 Expert** → Opens contact form or consultation scheduling page.  
4. Close the browser.

### Expected Result

- Each link should redirect correctly to its respective target page without errors.
