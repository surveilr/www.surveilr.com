---
FII: "TC-REG-0028"
groupId: "GRP-0011"
title: "Check - By Compliance Regime HIPAA Selection and Control Explorer Validation"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "HIPAA", "Control Explorer", "UI validation","Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting HIPAA from the 'By Compliance Regime' dropdown navigates correctly to the Control Explorer page.  
- Ensure that HIPAA controls are listed under the page, and the 'Download Checklist' and 'Talk to Our Experts' links are present and functional.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, expand the 'By Compliance Regime' dropdown and select **HIPAA**.
3. Click on the Control Explorer link.
4. Verify that the Control Explorer page loads successfully.  
5. Confirm that HIPAA controls are listed under the page.  
6. Verify that the **Download Checklist** link is visible and clickable.  
7. Verify that the **Talk to Our Experts** link is visible and clickable.  
8. Close the browser.

### Expected Result

- Selecting HIPAA should navigate to the Control Explorer page successfully.  
- HIPAA controls should be listed correctly under the page.  
- The **Download Checklist** link should be visible and functional.  
- The **Talk to Our Experts** link should be visible and functional.  
