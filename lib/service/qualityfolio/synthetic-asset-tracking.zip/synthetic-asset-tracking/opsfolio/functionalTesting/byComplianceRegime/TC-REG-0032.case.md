---
FII: "TC-REG-0032"
groupId: "GRP-0011"
title: "Check - CMMC Control Explorer Navigation, Tabs, and Action Links"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Compliance Regime", "CMMC", "Control Explorer", "UI validation", ]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting **By Compliance Regime → CMMC** navigates to the CMMC Control Explorer page and that all key elements (tabs, controls, action links) are displayed correctly.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, expand the **By Compliance Regime** dropdown and select **CMMC**.  
3. Verify that the page redirects to the **CMMC Control Explorer** section.  
4. Check that the following tabs are available:  
   - **CMMC Model 2.0 LEVEL 1**  
   - **CMMC Model 2.0 LEVEL 2**  
   - **CMMC Model 2.0 LEVEL 3**  
5. For each tab, click and verify that the respective controls are listed under it.  
6. Verify that the **Download CMMC Checklist** link is visible and functional.  
7. Verify that the **Talk to Our Experts** link is visible and functional.  
8. Close the browser.  

### Expected Result

- Navigation to **CMMC Control Explorer** page should be successful after selecting CMMC from the dropdown.  
- Tabs **CMMC Model 2.0 LEVEL 1, LEVEL 2, LEVEL 3** should be displayed and functional with their respective controls.  
- **Download CMMC Checklist** and **Talk to Our Experts** links should be present and functional.  
