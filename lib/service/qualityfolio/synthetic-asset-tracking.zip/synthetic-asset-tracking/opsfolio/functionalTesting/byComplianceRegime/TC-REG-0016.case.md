---
FII: "TC-REG-0016"  
groupId: "GRP-0011"  
title: "Check - Link Redirection on HITRUST Page"  
created_by: "arun-ramanan@netspective.in"  
created_at: "2025-09-17"  
test_type: "Manual"  
tags: ["By Compliance Regime", "Entry points - CTAs"]  
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"  
---

### Description  

- Validate that each link on the HITRUST page redirects to the correct target page.  

### Test Steps  

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → HITRUST**.  
3. Click on each link and verify redirection:  
   - **Start HITRUST Assessment** → Redirects to assessment initiation page or form.  
   - **Talk to HITRUST Expert** → Opens consultation/contact form with HITRUST expert.  
   - **Control Explorer** → Redirects to control explorer module for HITRUST controls.  
   - **Start HITRUST Assessment** (second occurrence) → Same behavior as the first link, no duplication error.  
   - **Download HITRUST Guide** → Initiates download or opens HITRUST guide resource.  
4. Close the browser.  

### Expected Result  

- Each link should redirect correctly to its respective target page or initiate download without errors.  
- Duplicate "Start HITRUST Assessment" links should behave consistently without conflict.  
