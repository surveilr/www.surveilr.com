---
id: GRP-0011
SuiteId: SUT-0002
planId: ["PLN-0002"]
name: "By Compliance Regime Dropdown Test Cases"
description: "Test cases validating the 'By Compliance Regime' dropdown functionality on the Opsfolio platform. It ensures that each compliance regime option (SOC2, HIPAA, ISO 27001, CMMC, FedRAMP, HITRUST, GDPR, PCI DSS, CCPA, European CRA) is visible, selectable, and correctly filters or routes compliance content according to the selected standard."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
tags: ["UI validation", "dropdown testing", "compliance content",  "framework filtering"]

---

## Overview

The 'By Compliance Regime' dropdown provides tailored access to different compliance frameworks in Opsfolio, including SOC2, HIPAA, ISO 27001, CMMC, FedRAMP, HITRUST, GDPR, PCI DSS, CCPA, and the European CRA. This test group ensures that the dropdown is fully functional, each option is selectable, and the platform routes or filters framework content appropriately based on the selected compliance regime.

## Key Functional Areas

### 🔹 Dropdown Visibility & Interaction

- **Dropdown Rendering**
  - Ensure the 'By Compliance Regime' dropdown is visible in the navigation bar.
  - Validate correct label display.

- **Option Selection**
  - Options to test:
    - SOC2
    - HIPAA
    - ISO 27001
    - CMMC
    - FedRAMP
    - HITRUST
    - GDPR
    - PCI DSS
    - CCPA
    - European CRA
  - Confirm that each option can be selected via mouse and keyboard.
  - Validate that dropdown closes after selection.

- **Content Filtering / Routing**
  - Verify that selecting a compliance regime filters or routes the framework content correctly.
  - Confirm compliance-specific messaging, resources, or CTAs appear according to selected regime.

### 🔹 Accessibility & Responsiveness

- Ensure keyboard navigation works across all options.
- Validate screen reader announcements for dropdown and options.
- Check dropdown visibility and interaction across mobile, tablet, and desktop.

### 🔹 UI & Design Consistency

- Confirm styling (font, color, spacing) matches design specifications.
- Ensure hover, focus, and active states are properly rendered.
- Validate no visual overlap or truncation occurs with long compliance names.

### 🔹 Error Handling & Edge Cases

- Test behavior when no compliance regimes are available or dropdown fails to load.
- Confirm fallback messaging or default selection is handled gracefully.
