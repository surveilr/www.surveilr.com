---
FII: "TC-REG-0022"
groupId: "GRP-0011"
title: "Check - Links Functionality on CCPA Compliance Regime Page"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "Entry points - CTAs"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that all primary action links on the CCPA compliance regime page are visible, clickable, and route to the correct destinations.  
- The links include: **Start CCPA Assessment**, **Legal Consultation**, **Start Implementation**, and **Privacy Consultation**.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → CCPA**.  
3. Verify that the following links are displayed on the page:  
   - Start CCPA Assessment  
   - Legal Consultation  
   - Start Implementation  
   - Privacy Consultation  
4. Click each link one by one and verify that it redirects to the correct page or opens the expected workflow/modal.  
5. Confirm that links are functional on desktop, tablet, and mobile viewports.  
6. Close the browser.

### Expected Result

- All four links should be visible on the CCPA page.  
- Clicking each link should redirect correctly or trigger the expected action.  
- Links should render and function properly across all devices.  
