---
FII: "TC-REG-0034"
groupId: "GRP-0011"
title: "Check - By Compliance Regime HITRUST Control Explorer Navigation and Link Validation"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Compliance Regime Dropdown", "HITRUST",  "UI validation"]
priority: "High"
test_cycles: ["1.0","1.1","1.2"]
scenario_type: "happy path"
---

### Description

- Validate that selecting HITRUST from the 'By Compliance Regime' dropdown correctly navigates to the Control Explorer page, where the controls are listed, and the page contains functional "Download HITRUST Checklist" and "Talk to Our Experts" links.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. From the navigation bar, select **By Compliance Regime → HITRUST**.  
3. On the HITRUST page, click the **Control Explorer** link.  
4. Verify that the Control Explorer page loads and contains a list of HITRUST controls.  
5. Check for the presence and visibility of the **Download HITRUST Checklist** link.  
6. Check for the presence and visibility of the **Talk to Our Experts** link.  
7. Close the browser.  

### Expected Result

- Selecting HITRUST from the dropdown should navigate to the HITRUST-specific page.  
- The **Control Explorer** page should load successfully and display a list of HITRUST controls.  
- The **Download HITRUST Checklist** link should be visible and clickable.  
- The **Talk to Our Experts** link should be visible and clickable.  
