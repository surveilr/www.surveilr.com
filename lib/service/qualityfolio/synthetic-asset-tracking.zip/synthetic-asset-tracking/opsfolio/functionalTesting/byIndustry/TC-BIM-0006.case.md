---
FII: "TC-BIM-0006"
groupId: "GRP-0013"
title: "Check whether the 'Health care' menu navigation is proper"
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-18"
test_type: "Manual"
tags: ["By Industry Page"]
priority: "High"
test_cycles: ["1.3","1.6"]
scenario_type: "happy path"

---

### Description

- Validate that when click on the 'Health care' menu in the By Industry menu the page navigate to the respective page.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Select the By Industry menu in the home page
3. Click on the 'Health care' from the menu list.
4. check whether the navigation is proper
5. Close the browser.

### Expected Result

- The 'Health care' menu should navigate to the respective page.
