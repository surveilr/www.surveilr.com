---
id: GRP-0013
SuiteId: SUT-0002
planId: ["PLN-0002"]
name: "By Industry Test Cases"
description: "Test cases validating the navigation, layout, responsiveness, and functionality of the 'By Industry' menu and its corresponding landing pages. It ensures that each industry option (Digital Health, Medical Devices, Government Contractors, Financial Services, SaaS & Tech, and Healthcare) is displayed correctly, routes to the appropriate compliance content, and provides a seamless user experience across devices."
created_by: "arun-ramanan@netspective.in"
created_at: "2025-09-17"
tags: ["UI validation",  "menu testing", "industry segmentation", "compliance mapping", "accessibility"]

---

## Overview

The **By Industry menu** provides users with compliance automation resources tailored to their sector. Selecting an industry (e.g., Digital Health or Financial Services) takes the user to a dedicated landing page containing industry-specific compliance information, frameworks, and calls-to-action. This test group validates the accuracy of navigation, industry-specific content rendering, responsiveness, and accessibility across all industries.

## Key Functional Areas

### 🔹 Global Navigation – By Industry Menu

* **Dropdown Visibility**

  * Validate that the "By Industry" dropdown is visible in the top navigation bar.
  * Ensure the dropdown expands on hover/click across all devices.
  * Confirm the following options are listed in order:

    1. Digital Health
    2. Medical Devices
    3. Government Contractors
    4. Financial Services
    5. SaaS & Tech
    6. Healthcare

* **Routing**

  * Validate that selecting each option routes the user to the correct landing page.
  * Confirm breadcrumbs display correctly (e.g., *Home → Industry → Digital Health*).
  * Validate that navigation is functional using both mouse and keyboard (Tab/Enter).

### 🔹 Industry Landing Pages

* **Header & Hero Section**

  * Validate the industry name is displayed correctly (e.g., *Digital Health Compliance*).
  * Confirm supporting text and visuals load correctly.
  * Check the primary CTA button (e.g., *Start Health Tech Assessment*) routes to the appropriate workflow.

* **Content Sections**

  * Validate that each industry page displays relevant compliance areas or sub-segments (e.g., *Telehealth Platforms, AI/Analytics* under Digital Health).
  * Confirm each card/tile is clickable and routes correctly.
  * Ensure descriptive text, icons, and labels load without errors.

### 🔹 Functional Elements

* **Call-to-Action Buttons**

  * Validate CTA buttons are present and functional across all industry pages.
  * Ensure CTAs link to relevant assessments, signup, or resources.

* **AI Assistant Widget**

  * Confirm AI assistant widget is visible and functional on all industry pages.
  * Validate user can interact (e.g., ask questions, access support).

### 🔹 Footer & Cross-Navigation

* Validate that the footer (About, Careers, Blog, Contact) is visible and functional on all industry pages.
* Ensure legal links (Privacy Policy, Terms of Service, Security Policy) open correctly.
* Confirm that switching to other menus (By Role, By Compliance Regime, etc.) works seamlessly from within an industry page.

### 🔹 Responsiveness & Performance

* Validate proper rendering of dropdown and landing pages on desktop, tablet, and mobile.
* Confirm dropdown collapses into hamburger/mobile menu view correctly.
* Test industry page load times and check for lazy loading of images/content.

---
