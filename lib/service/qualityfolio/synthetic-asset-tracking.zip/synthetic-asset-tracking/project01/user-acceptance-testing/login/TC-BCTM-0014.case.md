---
FII: "TC-BCTM-0014"
groupId: "GRP-0012"
title: "Check whether the 'Start Evidence Collection' button in the Collect Evidence page navigates properly"
created_by: "your-email@example.com"
created_at: "2025-10-01"
test_type: "Manual"
tags: ["By Compliance Task Page", "Conversion Paths - CTA buttons"]
priority: "High"
scenario_type: "happy path"
version: "1.0"
test_cycles: [ "1.1"]
related_requirements: ["REQ-102"]
status: "Draft"
bugId: ["BUG-BCTM-0014"]
---

### Description

- Validate that when click on the 'Start Evidence Collection' button in the Collect Evidence page navigate to the respective page.

### Test Steps

1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Hover on the 'By Compliance Task' menu in the home page
3. Click on the 'Collect Evidence' from the menu list
4. Click on the 'Start Evidence Collection' button
5. Close the browser

### Expected Result

- The 'Start Evidence Collection' button in the Collect Evidence page navigates properly.
