---
FII: "TC-BCTM-0001"
groupId: "GRP-0012"
title: "Check whether the 'Author Policies' menu navigation is proper"
created_by: "your-email@example.com"
created_at: "2025-10-01"
test_type: "Automation"
tags: ["By Compliance Task Page"]
priority: "High"
scenario_type: "happy path"
version: "1.1"
test_cycles: [ "1.1"]
related_requirements: ["REQ-101", "REQ-102"]
status: "Draft"
---

### Description

- Validate that when click on the 'Author Policies' menu in the By Compliance Task menu the page navigate to the respective page.

### Test Steps
 
1. Navigate to the URL (https://opsfolio.com) and ensure the page loads successfully.
2. Select the By Compliance Task menu in the home page.
3. Click on the 'Author Policies' from the menu list.
4. Check whether the navigation is proper to the respective URL.
5. Close the browser.

### Expected Result

- The 'Author Policies' menu should navigate to the respective page.
