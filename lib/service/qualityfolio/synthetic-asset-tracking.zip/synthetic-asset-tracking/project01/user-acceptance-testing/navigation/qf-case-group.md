---
id: GRP-0012
SuiteId: SUT-0002
planId: ["PLN-0002"]
name: "By Compliance Task Test Cases"
description: "Test cases validating the navigation, layout, responsiveness, and functionality of the 'By Compliance Task' menu and its corresponding landing pages. It ensures that each compliance task (Author Policies, Collect Evidence, Track Controls, Pass Audit, Verification & Validation, Test Management, Centralize Everything, Assets Intelligence, Threat Exposure Management) is displayed correctly, routes to the appropriate content, and provides a seamless user experience across devices."
created_by: "your-email@example.com"
created_at: "2025-10-01"
tags: ["UI validation", "navigation", "menu testing", "compliance tasks", "workflow validation", "accessibility"]
version: "1.0"
related_requirements: ["REQ-101", "REQ-102"]
status: "Draft"
---

## Overview

The **By Compliance Task menu** provides users with a functional entry point to different compliance workflows. Each task (such as *Author Policies* or *Collect Evidence*) links to a dedicated landing page or section that guides users through the respective compliance activity. This test group validates dropdown visibility, task-specific page routing, content accuracy, responsiveness, and accessibility across all tasks.

## Key Functional Areas

### 🔹 Global Navigation – By Compliance Task Menu

* **Dropdown Visibility**

  * Validate that the "By Compliance Task" dropdown is visible in the top navigation bar.
  * Confirm the dropdown expands on hover/click across all devices.
  * Ensure the following tasks are listed in order:

    1. Author Policies
    2. Collect Evidence
    3. Track Controls
    4. Pass Audit
    5. Verification & Validation (V\&V)
    6. Test Management
    7. Centralize Everything
    8. Assets Intelligence
    9. Threat Exposure Management

* **Routing**

  * Validate that selecting each option routes to the correct landing page.
  * Confirm breadcrumbs display correctly (e.g., *Home → Compliance Task → Collect Evidence*).
  * Validate navigation using both mouse clicks and keyboard (Tab/Enter).

### 🔹 Compliance Task Landing Pages

* **Header & Hero Section**

  * Validate the task title is displayed correctly (e.g., *Collect Evidence*).
  * Confirm description text loads properly.
  * Validate CTA buttons (e.g., *Start Evidence Collection*, *Run Test*) route to correct workflows.

* **Content Sections**

  * Validate each landing page provides relevant resources, tools, or workflows tied to that compliance task.
  * Confirm sub-sections (cards, tiles, or feature lists) are visible and clickable.
  * Ensure all visuals, icons, and labels load without errors.

### 🔹 Functional Elements

* **Call-to-Action Buttons**

  * Validate CTA buttons exist for each task and link correctly to next steps.
  * Confirm CTAs are accessible and functional across devices.

* **AI Assistant Widget**

  * Ensure AI assistant is visible on every compliance task page.
  * Validate interactions (ask questions, support links) work properly.

### 🔹 Footer & Cross-Navigation

* Validate that footer links (About, Careers, Blog, Contact) work correctly across task pages.
* Confirm legal links (Privacy Policy, Terms of Service, Security Policy) open correctly.
* Ensure other menus (By Role, By Industry, By Compliance Regime) remain functional from within task pages.

### 🔹 Responsiveness & Performance

* Validate rendering of dropdown and landing pages on desktop, tablet, and mobile.
* Ensure dropdown collapses into mobile navigation correctly.
* Test load times and lazy loading for task-specific content.

---


