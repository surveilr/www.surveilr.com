---
FII: "TR-BCTM-0014"
test_case_fii: "TC-BCTM-0014"
run_date: "2025-10-01"
environment: "Production"
---
 
### Run Summary
 
- Status: Failed
- Notes: Errors encountered:
Step 4: Error: [31mTimed out 5000ms waiting for [39m[2mexpect([22m[31mlocator[39m[2m).[22mtoHaveURL[2m([22m[32mexpected[39m[2m)[22m

Locator: locator(':root')
Expected string: [32m"https://opsfolio.com/[7mresources[27m"[39m
Received string: [31m"https://opsfolio.com/[7mget-started/[27m"[39m
Call log:
[2m  - expect.toHaveURL with timeout 5000ms[22m
[2m  - waiting for locator(':root')[22m
[2m    8 × locator resolved to <html lang="en" data-astro-cid-sckkx6r4="">…</html>[22m
[2m      - unexpected value "https://opsfolio.com/get-started/"[22m
