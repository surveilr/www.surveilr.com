---
issue_id: "BUG-BCTM-0014"
test_case_fii: "TC-BCTM-0014"
run_id: "TR-BCTM-0014"
groupId: "GRP-0012"
titleName: "The dropdown label is not displayed correctly"
endpoint: "By Compliance Regime"
created_by: "your-email@example.com"
created_at: "2025-10-01"
test_type: "Manual"
priority: "High"
severity: "Low"
assigned: "Mahesh"
status: "open"
---

### Description

The dropdown label is not displayed correctly on the UI, making it difficult for users to understand the selection field.

### Pre-requisites:

1. Access to the application.
2. Valid user credentials to log in.
3. Ensure the application is running and accessible.

### Test Steps

Step 1: Navigate to the page containing the dropdown.
Step 2: Observe the label text displayed above or inside the dropdown.

### Expected Result

- The dropdown label should be properly displayed with correct text, alignment, and visibility.

### Actual Result

- The dropdown label is either missing, cut off, or misaligned, resulting in an unclear user interface.

### Attachment

- screenshot: [screenshot](../project01/user-acceptance-testing/images/startButtonClick.png)