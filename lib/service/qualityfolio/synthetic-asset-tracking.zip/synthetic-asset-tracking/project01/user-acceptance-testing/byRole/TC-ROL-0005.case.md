---
FII: "TC-ROL-0005"
groupId: "GRP-0010"
title: "Check - Breadcrumb Navigation Visibility and Clickable Home Link on CTOs & Tech Leaders Page"
created_by: "your-email@example.com"
created_at: "2025-09-16"
test_type: "Manual"
tags: [ "By Role Dropdown"]
priority: "High"
scenario_type: ["happy path"]
version: "1.1"
test_cycles: ["1.0", "1.1","1.2"]
related_requirements: ["REQ-101"]
status: "Draft"
---

### Description

- Validate that the breadcrumb `Home / Role / CTOs & Tech Leaders` is displayed correctly on the CTOs & Tech Leaders page and that only the **Home** link is clickable.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. Expand the 'By Role' dropdown
3. Select 'CTOs & Tech Leaders' from dropdown
4. Verify breadcrumb displays 'Home / Role / CTOs & Tech Leaders'
5. Verify 'Home' is a clickable link
6. Verify 'Role' and 'CTOs & Tech Leaders' are not links
7. Click 'Home' link and verify redirect to homepage  
8. Close the browser.

### Expected Result

- The breadcrumb should be displayed as `Home / Role / CTOs & Tech Leaders`.  
- Only the **Home** breadcrumb should be clickable and should redirect correctly.  
- **Role** and **CTOs & Tech Leaders** should be displayed as non-clickable plain text.  
