---
FII: "TC-ROL-0004"
groupId: "GRP-0010"
title: "Check - By Role Dropdown Content Filtering and Role-Based Messaging"
created_by: "your-email@example.com"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Role Dropdown"]
priority: "High"
scenario_type: ["happy path"]
version: "1.1"
test_cycles: ["1.0", "1.1","1.2"]
related_requirements: ["REQ-101"]
status: "Draft"
---

### Description

- Validate that selecting a role filters or routes content correctly and displays tailored role-based messaging, recommendations, or CTAs.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Role' dropdown
3. Select 'CTOs & Tech Leaders' and verify correct URL redirection
4. Select 'CISOs & Security Engineers' and verify correct URL redirection
5. Select 'GRC & Compliance Leaders' and verify correct URL redirection
6. Select 'Founders & Business Leaders' and verify correct URL redirection
7. Select 'Auditors' and verify correct URL redirection
8. Close the browser.

### Expected Result

- Selecting a role should filter or route content accordingly.  
- Tailored role-based messaging, recommendations, or CTAs should appear per role.  
