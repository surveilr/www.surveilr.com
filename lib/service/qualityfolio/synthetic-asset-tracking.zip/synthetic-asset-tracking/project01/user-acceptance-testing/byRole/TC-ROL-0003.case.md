---
FII: "TC-ROL-0003"
groupId: "GRP-0010"
title: "Check - By Role Dropdown Option Selection and Closing Behavior"
created_by: "your-email@example.com"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Role Dropdown"]
priority: "High"
scenario_type: ["happy path"]
version: "1.1"
test_cycles: ["Cycle 1", "Cycle 2", "Cycle 3"]
related_requirements: ["REQ-103"]
status: "Draft"
---

### Description

- Validate that each dropdown option can be selected and that the dropdown closes after selection.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Role' dropdown
3. Select 'CTOs & Tech Leaders' using mouse click and verify dropdown closes
4. Select 'CISOs & Security Engineers' using mouse click and verify dropdown closes
5. Select 'GRC & Compliance Leaders' using mouse click and verify dropdown closes
6. Select 'Founders & Business Leaders' using mouse click and verify dropdown closes
7. Select 'Auditors' using mouse click and verify dropdown closes
8. Close the browser.

### Expected Result

- Each option should be selectable via both mouse and keyboard.  
- The dropdown should close automatically after each selection.  
