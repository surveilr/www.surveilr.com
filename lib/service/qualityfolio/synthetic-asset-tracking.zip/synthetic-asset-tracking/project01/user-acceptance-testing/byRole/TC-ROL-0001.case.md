---
FII: "TC-ROL-0001"
groupId: "GRP-0010"
title: "Check - By Role Dropdown Visibility and Label Rendering"
created_by: "your-email@example.com"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Role Dropdown"]
priority: "High"
scenario_type: ["happy path"]
version: "1.1"
test_cycles: ["Cycle 1", "Cycle 2", "Cycle 3"]
related_requirements: ["REQ-103"]
status: "Draft"
---

### Description

- Validate that the 'By Role' dropdown is visible in the navigation bar and its label is displayed correctly.

### Test Steps

1. Navigate to the Opsfolio homepage (https://opsfolio.com).  
2. Verify that the 'By Role' dropdown is visible in the navigation bar
3. Verify that the dropdown label is displayed correctly
4. Close the browser.

### Expected Result

- The 'By Role' dropdown should be visible on the homepage navigation bar.  
- The dropdown label should match the expected design text.  
