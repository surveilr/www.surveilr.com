---
FII: "TC-ROL-0002"
groupId: "GRP-0010"
title: "Check - By Role Dropdown Options Availability"
created_by: "your-email@example.com"
created_at: "2025-09-16"
test_type: "Manual"
tags: ["By Role Dropdown" ]
priority: "High"
scenario_type: ["happy path"]
version: "1.1"
test_cycles: ["Cycle 1", "Cycle 2", "Cycle 3"]
related_requirements: ["REQ-103"]
status: "Draft"
---

### Description

- Validate that all expected role options are available in the 'By Role' dropdown.

### Test Steps

1. Navigate to the Opsfolio homepage.  
2. Expand the 'By Role' dropdown
3. Verify the option 'CTOs & Tech Leaders' is listed in 'By Role' dropdown
4. Verify the option 'CISOs & Security Engineers' is listed in 'By Role' dropdown
5. Verify the option 'GRC & Compliance Leaders' is listed in 'By Role' dropdown
6. Verify the option 'Founders & Business Leaders' is listed in 'By Role' dropdown
7. Verify the option 'Auditors' is listed in 'By Role' dropdown
8. Close the browser.

### Expected Result

- All five role options should be present in the dropdown.  
